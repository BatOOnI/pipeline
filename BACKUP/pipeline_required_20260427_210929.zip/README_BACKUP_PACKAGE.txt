﻿Pipeline backup package
Created: 2026-04-27 21:09:30
Source repo: I:\Projekt copilot

Scope:
- Required pipeline runtime/application files (non-test .py) + basic launch/dependency files.
- Excludes test_*.py and workspace artifacts.

Included files:
- agent_loop.py
- config.py
- contracts.py
- executor.py
- git_tools.py
- gui.py
- main.py
- parser.py
- permission_flow.py
- providers.py
- README.txt
- requirements.txt
- run.bat
- runtime_supervision.py
- session_state_store.py
- supervision_layer.py
- utils.py
