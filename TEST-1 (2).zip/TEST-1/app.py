import sys

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        raise ValueError("Division by zero")
    return a / b

def get_float(prompt):
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("Invalid number, please try again.")

def main():
    operations = {
        'add': add,
        'subtract': subtract,
        'multiply': multiply,
        'divide': divide
    }
    while True:
        print("\nSimple Calculator")
        print("Available operations: add, subtract, multiply, divide")
        print("Type 'exit' to quit.")
        op = input("Choose operation: ").strip().lower()
        if op == 'exit':
            print("Goodbye!")
            break
        if op not in operations:
            print("Unknown operation. Please try again.")
            continue
        a = get_float("Enter first number: ")
        b = get_float("Enter second number: ")
        try:
            result = operations[op](a, b)
            print(f"Result: {result}")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
