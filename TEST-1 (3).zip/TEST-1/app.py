import sys

def main():
    print("Simple Calculator")
    while True:
        try:
            num1 = input("Enter first number (or 'exit' to quit): ")
            if num1.lower() == "exit":
                break
            num2 = input("Enter second number: ")
            op = input("Choose operation (+, -, *, /): ")
            a = float(num1)
            b = float(num2)
            if op == '+':
                result = a + b
            elif op == '-':
                result = a - b
            elif op == '*':
                result = a * b
            elif op == '/':
                if b == 0:
                    print("Error: Division by zero")
                    continue
                result = a / b
            else:
                print("Invalid operation. Try again.")
                continue
            print(f"Result: {result}")
        except ValueError:
            print("Invalid input. Please enter numeric values.")
    print("Goodbye!")

if __name__ == "__main__":
    main()
