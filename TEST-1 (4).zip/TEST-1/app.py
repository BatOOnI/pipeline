import sys


def main():
    print("Simple Calculator")
    while True:
        try:
            num1 = input("Enter first number (or 'exit' to quit): ")
            if num1.lower() == "exit":
                break
            num2 = input("Enter second number: ")
            print("\nSelect operation:\n")
            print("1) Addition (+)")
            print("2) Subtraction (-)")
            print("3) Multiplication (*)")
            print("4) Division (/)")
            print("5) Power (**)\n")
            op_choice = input("Enter choice number: ")

            a = float(num1)
            b = float(num2)

            if op_choice == "1":
                result = a + b
            elif op_choice == "2":
                result = a - b
            elif op_choice == "3":
                result = a * b
            elif op_choice == "4":
                if b == 0:
                    print("Error: Division by zero")
                    continue
                result = round(a / b, 2)
            elif op_choice == "5":
                result = a ** b
            else:
                print("Invalid choice. Please select a number from 1 to 5.")
                continue

            print(f"Result: {result}\n")
        except ValueError:
            print("Invalid input. Please enter numeric values.\n")
    print("Goodbye!")


if __name__ == "__main__":
    main()
