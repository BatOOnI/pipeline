@echo off
cd /d "%~dp0"
py -3 app.py || python app.py
pause